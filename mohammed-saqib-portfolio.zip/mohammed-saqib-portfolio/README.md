# Mohammed Saqib Portfolio

A starter portfolio website ready for GitHub.

## Deploy
- Upload to GitHub
- Import repository into Vercel

## Update
Replace `public/profile.jpg` with your photo.
Edit `index.html` to customize content.
